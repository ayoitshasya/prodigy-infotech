let timer;
let running = false;
let startTime;
let elapsedTime = 0;

const display = document.getElementById('display');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const resetBtn = document.getElementById('resetBtn');
const lapBtn = document.getElementById('lapBtn');
const laps = document.getElementById('laps');

function formatTime(time) {
    const date = new Date(time);
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');
    const milliseconds = String(date.getUTCMilliseconds()).padStart(3, '0');
    return `${minutes}:${seconds}:${milliseconds}`;
}

function updateDisplay() {
    const now = Date.now();
    elapsedTime = now - startTime;
    display.textContent = formatTime(elapsedTime);
}

function startTimer() {
    startTime = Date.now() - elapsedTime;
    timer = setInterval(updateDisplay, 10);
    running = true;
    startBtn.style.display = 'none';
    stopBtn.style.display = 'inline';
    resetBtn.style.pointerEvents = 'none';
    resetBtn.style.opacity = '0.5';
    document.body.style.backgroundColor = '#e0f7fa';
}

function stopTimer() {
    clearInterval(timer);
    running = false;
    startBtn.style.display = 'inline';
    stopBtn.style.display = 'none';
    resetBtn.style.pointerEvents = 'auto';
    resetBtn.style.opacity = '1';
    document.body.style.backgroundColor = '#f0f0f0';
}

function resetTimer() {
    clearInterval(timer);
    running = false;
    elapsedTime = 0;
    display.textContent = '00:00:00';
    laps.innerHTML = '';
    laps.style.display = 'none'; 
    startBtn.style.display = 'inline';
    stopBtn.style.display = 'none';
    resetBtn.style.pointerEvents = 'none';
    resetBtn.style.opacity = '0.5';
    document.body.style.backgroundColor = '#f0f0f0';
}

function lapTime() {
    if (running) {
        if (laps.style.display === 'none') {
            laps.style.display = 'block'; 
        }
        const lap = document.createElement('div');
        lap.className = 'lap';
        lap.textContent = formatTime(elapsedTime);
        laps.appendChild(lap);
    }
}

startBtn.addEventListener('click', startTimer);
stopBtn.addEventListener('click', stopTimer);
resetBtn.addEventListener('click', resetTimer);
lapBtn.addEventListener('click', lapTime);