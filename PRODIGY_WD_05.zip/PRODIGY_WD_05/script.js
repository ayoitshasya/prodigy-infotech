const apiKey = '9a106c86759f7ce58d231c359c1d22a4';

document.getElementById('get-weather-btn').addEventListener('click', () => {
    const location = document.getElementById('location-input').value;
    getWeather(location);
});

function getWeather(location) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.cod === 200) {
                displayWeather(data);
            } else {
                alert('Location not found. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
        });
}

function displayWeather(data) {
    const locationName = document.getElementById('location-name');
    const weatherConditions = document.getElementById('weather-conditions');
    const temperature = document.getElementById('temperature');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('wind-speed');

    locationName.textContent = data.name + ', ' + data.sys.country;
    weatherConditions.textContent = getWeatherEmoji(data.weather[0].description) + ' ' + data.weather[0].description;
    temperature.textContent = '🌡️ Temperature: ' + data.main.temp + '°C';
    humidity.textContent = '💧 Humidity: ' + data.main.humidity + '%';
    windSpeed.textContent = '🌬️ Wind Speed: ' + data.wind.speed + ' m/s';
}

function getWeatherEmoji(description) {
    const weatherDescription = description.toLowerCase();
    if (weatherDescription.includes('clear')) {
        return '☀️';
    } else if (weatherDescription.includes('clouds')) {
        return '☁️';
    } else if (weatherDescription.includes('rain')) {
        return '🌧️';
    } else if (weatherDescription.includes('snow')) {
        return '❄️';
    } else if (weatherDescription.includes('thunderstorm')) {
        return '⛈️';
    } else {
        return '🌈';
    }
}
